/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;
import service.Service;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class Main {
    public static void main(String[] args) {
        Service service = new Service(); 
        try (Scanner scanner = new Scanner(System.in)) {
            int pilihan = -1;
            
            while (pilihan != 0) {
                System.out.println("\n=== MENU SEWA BUSANA ===");
                System.out.println("1. Tambah Busana");
                System.out.println("2. Tampilkan Busana");
                System.out.println("3. Ubah Busana");
                System.out.println("4. Hapus Busana");
                System.out.println("5. Cari Busana");
                System.out.println("0. Keluar");
                System.out.print("Pilih menu: ");
                
                // Validasi input biar ga error kalau user masukin huruf
                if (scanner.hasNextInt()) {
                    pilihan = scanner.nextInt();
                    scanner.nextLine(); // buang enter
                } else {
                    System.out.println("❌ Input harus berupa angka.");
                    scanner.nextLine();
                    continue;
                }
                
                switch (pilihan) {
                    case 1 -> service.tambahBusana();
                    case 2 -> service.tampilkanBusana();
                    case 3 -> service.ubahBusana();
                    case 4 -> service.hapusBusana();
                    case 5 -> service.cariBusana();
                    case 0 -> System.out.println("✅ Terima kasih, program selesai!");
                    default -> System.out.println("❌ Pilihan tidak valid, coba lagi.");
                }
            }
        }
    }
}