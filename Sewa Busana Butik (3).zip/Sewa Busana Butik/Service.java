/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import com.mycompany.SewaBusanaButik.Busana;
import BusanaService.BusanaTradisional;
import BusanaService.BusanaModern;
import java.util.ArrayList;
import java.util.Scanner;

public class Service {
    private final ArrayList<Busana> daftarBusana = new ArrayList<>();
    private final Scanner scanner = new Scanner(System.in);

    // CREATE
    public void tambahBusana() {
        System.out.print("Masukkan ID Busana: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        for (Busana b : daftarBusana) {
            if (b.getId() == id) {
                System.out.println("❌ ID sudah digunakan!");
                return;
            }
        }

        System.out.print("Masukkan Nama Busana: ");
        String nama = scanner.nextLine();

        System.out.print("Masukkan Harga Sewa: ");
        double harga = scanner.nextDouble();
        scanner.nextLine();

        System.out.println("Pilih jenis busana:");
        System.out.println("1. Tradisional");
        System.out.println("2. Modern");
        int jenis = scanner.nextInt();
        scanner.nextLine();

        Busana busana;
        if (jenis == 1) {
            System.out.print("Masukkan Asal Daerah: ");
            String asal = scanner.nextLine();
            busana = new BusanaTradisional(id, nama, harga, asal);
        } else {
            System.out.print("Masukkan Kategori (Gaun, Jas, dll): ");
            String kategori = scanner.nextLine();
            busana = new BusanaModern(id, nama, harga, kategori);
        }

        daftarBusana.add(busana);
        System.out.println("✅ Busana berhasil ditambahkan!");
    }

    // READ
    public void tampilkanBusana() {
        if (daftarBusana.isEmpty()) {
            System.out.println("⚠️ Belum ada data busana.");
            return;
        }
        for (Busana b : daftarBusana) {
            System.out.println(b);
        }
    }

    // UPDATE
    public void ubahBusana() {
        System.out.print("Masukkan ID Busana yang ingin diubah: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        for (Busana b : daftarBusana) {
            if (b.getId() == id) {
                System.out.print("Masukkan Nama Baru: ");
                String nama = scanner.nextLine();
                System.out.print("Masukkan Harga Sewa Baru: ");
                double harga = scanner.nextDouble();
                scanner.nextLine();

                b.setNama(nama);
                b.setHargaSewa(harga);
                System.out.println("✅ Data berhasil diupdate!");
                return;
            }
        }
        System.out.println("❌ Busana tidak ditemukan.");
    }

    // DELETE
    public void hapusBusana() {
        System.out.print("Masukkan ID Busana yang ingin dihapus: ");
        int id = scanner.nextInt();

        boolean removed = daftarBusana.removeIf(b -> b.getId() == id);
        if (removed) {
            System.out.println("✅ Busana berhasil dihapus!");
        } else {
            System.out.println("❌ Busana tidak ditemukan.");
        }
    }

    // SEARCH
    public void cariBusana() {
        System.out.print("Masukkan kata kunci pencarian: ");
        scanner.nextLine(); // buang enter
        String keyword = scanner.nextLine();

        boolean ditemukan = false;
        for (Busana b : daftarBusana) {
            if (b.getNama().toLowerCase().contains(keyword.toLowerCase())) {
                System.out.println(b);
                ditemukan = true;
            }
        }
        if (!ditemukan) {
            System.out.println("⚠️ Busana tidak ditemukan.");
        }
    }
}