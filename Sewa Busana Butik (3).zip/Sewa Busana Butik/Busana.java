package com.mycompany.SewaBusanaButik;

public class Busana {
    private final int id;
    private String nama;
    private double hargaSewa;

    // Constructor
    public Busana(int id, String nama, double hargaSewa) {
        this.id = id;
        this.nama = nama;
        this.hargaSewa = hargaSewa;
    }

    // Getter & Setter
    public int getId() {
        return id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public double getHargaSewa() {
        return hargaSewa;
    }

    public void setHargaSewa(double hargaSewa) {
        this.hargaSewa = hargaSewa;
    }

    @Override
    public String toString() {
        return "ID: " + id + " | Nama: " + nama + " | Harga Sewa: Rp" + hargaSewa;
    }
}